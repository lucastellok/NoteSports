const API_URL = 'http://localhost:5000';

async function solicitarReserva(event) {
    event.preventDefault();

    const nome = document.getElementById('nome').value.trim();
    const telefone = document.getElementById('telefone').value.trim();
    const nome_quadra = document.getElementById('reserva').value.trim();
    const data_reserva = document.getElementById('data').value.trim();
    const horario = document.getElementById('horario').value.trim();

    // Validação
    if (!nome || !telefone || !nome_quadra || !data_reserva || !horario) {
        alert("Erro: Todos os campos são obrigatórios");
        return;
    }

    const reserva = {
        nome: nome,
        telefone: telefone,
        reserva: nome_quadra,
        data: data_reserva,
        horario: horario
    };

    try {
        const response = await fetch(`${API_URL}/solicitacao`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(reserva)
        });

        const result = await response.json();

        if (response.ok) {
            alert("Reserva solicitada com sucesso");
            document.getElementById('nome').value = "";
            document.getElementById('telefone').value = "";
            document.getElementById('reserva').value = "";
            document.getElementById('data').value = "";
            document.getElementById('horario').value = "";
        } else {
            alert("Erro ao solicitar reserva: " + (result.message || "Erro desconhecido"));
        }

    } catch (error) {
        console.error("Erro ao solicitar reserva:", error);
        alert("Erro de conexão. Verifique se a API está rodando.");
    }
}
