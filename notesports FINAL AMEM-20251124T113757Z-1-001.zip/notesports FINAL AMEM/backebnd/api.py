
from flask import Flask, jsonify, request
from flask_restful import Resource, Api
from flask_cors import CORS
import psycopg2
from psycopg2.extras import RealDictCursor

app = Flask(__name__)
api = Api(app)
CORS(app)

DB_HOST = "localhost"
DB_NAME = "notesports"
DB_USER = "postgres"
DB_PASS = "root"
DB_PORT = 5432

def get_db_connection():
    return psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASS,
        port=DB_PORT,
        cursor_factory=RealDictCursor
    )

class MostrarQuadras(Resource):
    def get(self):
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM quadras;")
        rows = cur.fetchall()
        cur.close()
        conn.close()
        return {"Quadras disponiveis": rows}

class MostrarHorarios(Resource):
    def get(self):
        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute("SELECT * FROM horarios;")
        rows = cur.fetchall()
        cur.close()
        conn.close()

        for item in rows:
            for key, value in item.items():
                if hasattr(value, "isoformat"):
                    item[key] = value.isoformat()

        return {"Horários disponíveis": rows}

class CadastrarUsuario(Resource):
    def post(self):
        dados_usuario = request.get_json()
        nome = dados_usuario.get("Nome")
        email = dados_usuario.get("Email")
        telefone = dados_usuario.get("Telefone")
        senha = dados_usuario.get("Senha")

        if not nome or not email or not telefone or not senha:
            return {"message": "Todos os campos são obrigatórios!"}, 400

        conn = get_db_connection()
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO usuarios (nome, email, telefone, senha_hash) VALUES (%s, %s, %s, %s)",
            (nome, email, telefone, senha),
        )
        conn.commit()
        cur.close()
        conn.close()

        return {"message": "Usuário cadastrado com sucesso!"}

class SolicitarReserva(Resource):
    def post(self):
        dados_reserva = request.get_json()
        nome = dados_reserva.get("nome")
        telefone = dados_reserva.get("telefone")
        nome_quadra = dados_reserva.get("reserva")
        data_reserva = dados_reserva.get("data")
        horario = dados_reserva.get("horario")

        if not nome or not telefone or not nome_quadra or not data_reserva or not horario:
            return {"message": "Todos os campos são obrigatórios!"}, 400

        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute("SELECT id_quadra FROM quadras WHERE nome=%s", (nome_quadra,))
        quadra = cur.fetchone()
        if not quadra:
            cur.close()
            conn.close()
            return {"message": "Quadra não encontrada!"}, 404

        id_quadra = quadra["id_quadra"]

        # VERIFICAR CONFLITO DE HORÁRIO
        cur.execute("""
            SELECT * FROM reservas
            WHERE id_quadra = %s AND data_reserva = %s AND horario = %s
        """, (id_quadra, data_reserva, horario))
        conflito = cur.fetchone()

        if conflito:
            cur.close()
            conn.close()
            return {"message": "Erro: Esse horário já está reservado!"}, 400

        # Inserir reserva
        cur.execute(
            """
            INSERT INTO reservas (nome_usuario, telefone_usuario, id_quadra, nome_quadra, data_reserva, horario, status)
            VALUES (%s, %s, %s, %s, %s, %s, 'Pendente')
            """,
            (nome, telefone, id_quadra, nome_quadra, data_reserva, horario)
        )
        conn.commit()
        cur.close()
        conn.close()

        return {"message": "Reserva solicitada com sucesso!"}
    
class HistoricoReservas(Resource):
    def get(self):
        nome = request.args.get("nome")
        telefone = request.args.get("telefone")

        if not nome or not telefone:
            return {"message": "Informe nome e telefone para consultar o histórico!"}, 400

        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute(
            """
            SELECT id_reserva, nome_quadra, data_reserva, horario, status
            FROM reservas
            WHERE nome_usuario = %s AND telefone_usuario = %s
            ORDER BY data_reserva DESC, horario DESC;
            """,
            (nome, telefone)
        )

        reservas = cur.fetchall()
        cur.close()
        conn.close()

        for item in reservas:
            for key, value in item.items():
                if hasattr(value, "isoformat"):
                    item[key] = value.isoformat()

        return {"Histórico de Reservas": reservas}
    
class MostrarTodasReservas(Resource):
    def get(self):
        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute("""
            SELECT id_reserva, nome_usuario, telefone_usuario, nome_quadra,
                   data_reserva, horario, status
            FROM reservas
            ORDER BY data_reserva DESC, horario DESC;
        """)
        reservas = cur.fetchall()

        cur.close()
        conn.close()

        for item in reservas:
            for key, value in item.items():
                if hasattr(value, "isoformat"):
                    item[key] = value.isoformat()

        return {"Reservas realizadas": reservas}

class StatusReserva(Resource):
    def put(self, id_reserva):
        dados = request.get_json()
        novo_status = dados.get("status")

        if novo_status not in ["Aprovada", "Reprovada"]:
            return {"message": "Status inválido! Use 'Aprovada' ou 'Reprovada'."}, 400

        conn = get_db_connection()
        cur = conn.cursor()

        # Busca a reserva pelo ID
        cur.execute("SELECT * FROM reservas WHERE id_reserva = %s", (id_reserva,))
        reserva = cur.fetchone()

        if not reserva:
            cur.close()
            conn.close()
            return {"message": "Reserva não encontrada!"}, 404

        # Atualiza apenas essa reserva
        cur.execute(
            "UPDATE reservas SET status = %s WHERE id_reserva = %s",
            (novo_status, id_reserva)
        )
        conn.commit()

        cur.close()
        conn.close()

        return {
            "message": f"Reserva {id_reserva} atualizada para: {novo_status}"
        }
class Estatisticas(Resource):
    def get(self):
        conn = get_db_connection()
        cur = conn.cursor()

        # Total de reservas
        cur.execute("SELECT COUNT(*) AS total FROM reservas;")
        total_reservas = cur.fetchone()['total']

        # Reservas por status
        cur.execute("""
            SELECT status, COUNT(*) AS quantidade
            FROM reservas
            GROUP BY status;
        """)
        status_rows = cur.fetchall()
        reservas_por_status = {row['status']: row['quantidade'] for row in status_rows}

        # Total de usuários
        cur.execute("SELECT COUNT(*) AS total FROM usuarios;")
        total_usuarios = cur.fetchone()['total']

        # Quadras mais usadas
        cur.execute("""
            SELECT nome_quadra AS nome,
                   COUNT(*) AS total_reservas
            FROM reservas
            GROUP BY nome_quadra
            ORDER BY total_reservas DESC
            LIMIT 3;
        """)
        quadras_populares = cur.fetchall()

        cur.close()
        conn.close()

        return {
            "total_reservas": total_reservas,
            "reservas_por_status": reservas_por_status,
            "total_usuarios": total_usuarios,
            "quadras_populares": quadras_populares
        }
class DeletarReserva(Resource):
    def delete(self, id_reserva):
        conn = get_db_connection()
        cur = conn.cursor()

        cur.execute("SELECT * FROM reservas WHERE id_reserva = %s", (id_reserva,))
        reserva = cur.fetchone()

        if not reserva:
            cur.close()
            conn.close()
            return {"message": "Reserva não encontrada!"}, 404

        cur.execute("DELETE FROM reservas WHERE id_reserva = %s", (id_reserva,))
        conn.commit()

        cur.close()
        conn.close()

        return {"message": f"Reserva {id_reserva} deletada com sucesso!"}



api.add_resource(MostrarQuadras, "/quadras")
api.add_resource(MostrarHorarios, "/horarios")
api.add_resource(CadastrarUsuario, "/cadastro")
api.add_resource(SolicitarReserva, "/solicitacao")
api.add_resource(HistoricoReservas, "/historico")
api.add_resource(MostrarTodasReservas, "/admreservas")
api.add_resource(StatusReserva, "/reserva/<int:id_reserva>/status")
api.add_resource(Estatisticas, "/estatisticas")
api.add_resource(DeletarReserva, "/reserva/deletar/<int:id_reserva>")




if __name__ == "__main__":
    app.run(port=5000, host="localhost", debug=True)